const express = require('express');
const app = express();
const PORT = 3000;

// Define the server-side data object: githubPublicData
let githubPublicData = {
  username: "ankit123",
  fullName: "Ankit Kumar",
  email: "ankit@email.com",
  repositories: 24,
  gists: 12,
  joinedOn: "Sep 2018"
};

// Function to get the public email from githubPublicData
function getPublicEmail(githubPublicData) {
  return githubPublicData.email;
}

app.get("/github-public-email", (req, res) => {
  let publicEmail = getPublicEmail(githubPublicData);
  res.json({ publicEmail: publicEmail });
});

// Function to get the count of repositories
function getReposCount(githubPublicData) {
  return githubPublicData.repositories;
}

app.get("/github-repos-count", (req, res) => {
  let reposCount = getReposCount(githubPublicData);
  res.json({ reposCount: reposCount });
});

// Function to get the count of gists
function getGistsCount(githubPublicData) {
  return githubPublicData.gists;
}

app.get("/github-gists-count", (req, res) => {
  let gistsCount = getGistsCount(githubPublicData);
  res.json({ gistsCount: gistsCount });
});

// Function to get the user bio details
function getUserBio(githubPublicData) {
  return {
    fullName: githubPublicData.fullName,
    joinedOn: githubPublicData.joinedOn,
    email: githubPublicData.email
  };
}

app.get("/github-user-bio", (req, res) => {
  let userBio = getUserBio(githubPublicData);
  res.json(userBio);
});

// Function to generate the GitHub repository URL
function getRepoUrl(githubPublicData, repoName) {
  return `https://github.com/${githubPublicData.username}/${repoName}`;
}

app.get("/github-repo-url", (req, res) => {
  let repoName = req.query.repoName;
  let repoUrl = getRepoUrl(githubPublicData, repoName);
  res.json({ repoUrl: repoUrl });
});

// Start the server on the defined port
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});