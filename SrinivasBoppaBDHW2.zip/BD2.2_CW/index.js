const express = require('express');
const app = express();
const PORT = 3000;

//Array of numbers  
let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// function to filter even numbers
function filterEvenNumbers(num) {
  return num % 2 === 0;
}
// Endpoint 1: Given an array of numbers, returns only the even numbers
app.get('/even-numbers', (req, res) => {
  let result = numbers.filter((num) => filterEvenNumbers(num));
  res.json(result);
});

//Array of ages  
let ages = [10, 20, 30, 15, 17, 25];

// function to filter ages greater than 18
function filterAgeGreaterThan18(age) {
  return age > 18;
}
// Endpoint 2: Given an array of ages, returns the ages greater than 18
app.get('/adult-ages', (req, res) => {
  let result = ages.filter((age) => filterAgeGreaterThan18(age));
  res.json(result);
});


//Array of words
let words = ["apple", "banana", "cherry", "date", "fig", "grape"];

// function to filter words longer than five characters
function filterWordsGreaterThanFiveChars(word) {
  return word.length > 5;
}

// Endpoint 3: Given an array of words, returns the only the words longer than 5 characters
app.get('/long-words', (req, res) => {
  let result = words.filter((word) => filterWordsGreaterThanFiveChars(word));
  res.json(result);
});

//Array of file sizes in MB
let fileSizes = [50,200, 75, 120, 90,19, 150]

// function to filter files in smaller than a certain size
function filterSmallerFileSizes(fileSize, filterParam){
  return fileSize < filterParam;
}

// Endpoint 4: Given an array of file sizes in MB, returns only the files smaller than a certain size
app.get("/small-files", (req, res) => {
  let filterParam = parseFloat(req.query.filterParam);
  let results = fileSizes.filter((fileSize) => filterSmallerFileSizes(fileSize, filterParam),
);
  res.json(results);
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});